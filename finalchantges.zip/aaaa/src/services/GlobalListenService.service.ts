import {Injectable,EventEmitter} from '@angular/core';

@Injectable()
export class GlobalListenService
{
public globalEmitter:EventEmitter<any>;
public isOpen:boolean=false;

constructor(){


    this.globalEmitter=new EventEmitter<any>();
}

public emitGlobally(emitter:any){

this.globalEmitter.emit(emitter);

}






}
