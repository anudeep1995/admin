import { Component, Injectable } from '@angular/core';
import { GlobalListenService } from 'src/services/GlobalListenService.service';

@Component({
  selector: 'nav-root',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {
  title = 'admin';

public open:string="";

constructor(@Injectable() public globallisten:GlobalListenService){
}



openNav()
{
  console.log("entered open nav "+this.open);

  if(this.open=="")
{
this.open="open";
this.globallisten.isOpen=true;//global variable of service class
this.globallisten.emitGlobally({ event: "open" , obj:true });
}
else{
  this.globallisten.isOpen=false;
  this.open="";
  this.globallisten.emitGlobally({ event: "close" , obj:false });
}
}




















}
