import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { FirstlinkComponent } from './firstlink/firstlink.component';
import { GlobalListenService } from 'src/services/GlobalListenService.service';
import { SecondLinkComponent } from './secondlink/secondlink.component';

@NgModule({
  declarations: [
    AppComponent,NavbarComponent,FirstlinkComponent,SecondLinkComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [GlobalListenService],
  bootstrap: [AppComponent]
})
export class AppModule { }
