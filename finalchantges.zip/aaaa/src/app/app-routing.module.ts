import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FirstlinkComponent } from './firstlink/firstlink.component';
import { SecondLinkComponent } from './secondlink/secondlink.component';

const routes: Routes = [

  { path: 'firstlink', component: FirstlinkComponent },
  { path: 'secondlink', component: SecondLinkComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
