import { Component, Injectable , OnInit } from '@angular/core';
import { GlobalListenService } from 'src/services/GlobalListenService.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'second-link',
  templateUrl: './secondlink.component.html',
  styleUrls: ['./secondlink.component.css']
})
export class SecondLinkComponent implements OnInit {
  title = 'admin';

public open:string="";

constructor(@Injectable() public globallisten:GlobalListenService){
}

ngOnInit(){
const globallistensubsciption:Subscription=this.globallisten.globalEmitter.subscribe((event)=>{
  if(event.event=="open"){
  this.open="open";
  }else if(event.event="close"){
    this.open="";
  }
})
 if(this.globallisten.isOpen){
  this.open="open";
 } else{
  this.open="";
 }


}

openNav()
{
  console.log("entered open nav "+this.open);

  if(this.open="")
{
this.open="open";
}
else{
  this.open="";
}
}

}
