import { Component, Injectable , OnInit } from '@angular/core';
import { GlobalListenService } from 'src/services/GlobalListenService.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'first-link',
  templateUrl: './firstlink.component.html',
  styleUrls: ['./firstlink.component.css']
})
export class FirstlinkComponent implements OnInit {
  title = 'admin';

public open:string="";
private globallistensubscription:Subscription;




constructor(@Injectable() public globallisten:GlobalListenService){
}

ngOnInit(){
 this.globallistensubscription=this.globallisten.globalEmitter.subscribe((event)=>{
  if(event.event=="open"){
  this.open="open";
  }else if(event.event="close"){
    this.open="";
  }
})
 if(this.globallisten.isOpen){
  this.open="open";
 } else{
  this.open="";
 }


}



ngOnDestroy()
{

this.globallistensubscription.unsubscribe();
console.log("closef raier");
}
}
